if compiled?('dl') and $mswin||$bccwin||$mingw||$cygwin
  create_makefile('win32')
end
