require 'mkmf'
create_makefile('json')

